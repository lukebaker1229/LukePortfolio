﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooScenario.Business_Classes
{
    /// <summary>
    /// The Vending machine class.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public class VendingMachine
    {
        /// <summary>
        /// The price of food (per pound).
        /// </summary>
        public decimal FoodPricePerPound;

        /// <summary>
        /// The amount of food currently in stock (in pounds).
        /// </summary>
        public double FoodStock;

        /// <summary>
        /// The amount of money currently in the vending machine.
        /// </summary>
        public decimal MoneyBalance;

        /// <summary>
        /// The method for adding money.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1611:Element parameters should be documented", Justification = "idk")]
        public void AddMoney(decimal amount)
        {
            this.MoneyBalance += amount;
        }

        /// <summary>
        /// The method for removing money.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1611:Element parameters should be documented", Justification = "idk")]
        public double SellFood(decimal payment)
        {
            double foodWeight;
            foodWeight = (double)(payment * this.FoodPricePerPound);
            this.AddMoney(payment);
            this.FoodStock = Math.Round(this.FoodStock - foodWeight, 2);
            return foodWeight;
        }

        /// <summary>
        /// Param.
        /// </summary>
        /// <returns>t.</returns>
        public decimal DetermineFoodCost(double maxFoodWeight)
        {
            decimal maxFoodCost = (decimal)(maxFoodWeight * (double)(this.FoodPricePerPound));

            // Round the food cost to the nearest hundredth.
            decimal foodCost = Math.Round(maxFoodCost, 2);
            return foodCost;
        }
    }
}
