﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooScenario.Business_Classes
{
    /// <summary>
    /// The class which is used to represent the wallet.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public class Wallet
    {
        /// <summary>
        /// The amount of money currently contained within the wallet.
        /// </summary>
        public decimal MoneyBalance;

        /// <summary>
        /// Removes a specified amount of money from the wallet.
        /// </summary>
        /// <returns>ve.</returns>
#pragma warning disable SA1611 // Element parameters should be documented
        public decimal RemoveMoney(decimal amount)
#pragma warning restore SA1611 // Element parameters should be documented
        {
            decimal amountRemoved;

            // Don't remove a negative amount.
            if (amount > 0.00m)
            {
                amountRemoved = amount;
            }
            else
            {
                amountRemoved = 0.00m;
            }

            this.MoneyBalance = this.MoneyBalance - amountRemoved;
            return amountRemoved;
        }
    }
}
