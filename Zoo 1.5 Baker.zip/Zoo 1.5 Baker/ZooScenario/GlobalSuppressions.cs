﻿// This file is used by Code Analysis to maintain SuppressMessage
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given
// a specific target and scoped to a namespace, type, member, etc.

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1611:Element parameters should be documented", Justification = "idk", Scope = "member", Target = "~M:ZooScenario.Business_Classes.Guest.RemoveMoney(System.Decimal)")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1600:Elements should be documented", Justification = "<n>", Scope = "member", Target = "~M:ZooScenario.Animal.GetPortionSize~System.Double")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1600:Elements should be documented", Justification = "<n>", Scope = "member", Target = "~M:ZooScenario.Animal.GetPortionSize(System.Double)~System.Double")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1611:Element parameters should be documented", Justification = "<n>", Scope = "member", Target = "~M:ZooScenario.Business_Classes.VendingMachine.DetermineFoodCost(System.Double)~System.Decimal")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1611:Element parameters should be documented", Justification = "<nn>", Scope = "member", Target = "~M:ZooScenario.Business_Classes.VendingMachine.GetMoneyBalance(System.Decimal)")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1615:Element return value should be documented", Justification = "<v>", Scope = "member", Target = "~M:ZooScenario.Business_Classes.VendingMachine.SellFood(System.Decimal)~System.Double")]
