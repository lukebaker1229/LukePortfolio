﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ZooScenario.Business_Classes;

namespace ZooScenario
{
    /// <summary>
    /// Contains interaction logic for MainWindow.xaml.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Event handlers may begin with lower-case letters.")]
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Field that represents the Como Zoo.
        /// </summary>
        public Zoo ComoZoo;

        /// <summary>
        /// Field that represents the San Diego Zoo.
        /// </summary>
        public Zoo SanDiegoZoo;

        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Creates the Como Zoo and related objects.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void newComoZooButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the Zoo class.
            this.ComoZoo = new Zoo();

            // Set field values of Como Zoo
            this.ComoZoo.AnimalSnackMachine = new VendingMachine();

            this.ComoZoo.BirthArea = new BirthingRoom();

            this.ComoZoo.Capacity = 1000;

            this.ComoZoo.FeaturedAnimal = new Animal();

            this.ComoZoo.LadiesRoom = new Restroom();

            this.ComoZoo.MensRoom = new Restroom();

            this.ComoZoo.Name = "Como Zoo";

            this.ComoZoo.TicketBooth = new Booth();

            this.ComoZoo.BirthArea.Mother = this.ComoZoo.FeaturedAnimal;
            this.ComoZoo.BirthArea.Temperature = 77.0;
            this.ComoZoo.BirthArea.Doctor = new Employee();
            this.ComoZoo.BirthArea.Doctor.Name = "Flora";
            this.ComoZoo.BirthArea.Doctor.Number = 98;

            this.ComoZoo.AnimalSnackMachine.FoodPricePerPound = 0.75m;
            this.ComoZoo.AnimalSnackMachine.FoodStock = 250.0;
            this.ComoZoo.AnimalSnackMachine.MoneyBalance = 42.75m;

            // Assign field values of the featured animal
            this.ComoZoo.FeaturedAnimal.Age = 4;
            this.ComoZoo.FeaturedAnimal.Gender = "Female";
            this.ComoZoo.FeaturedAnimal.Name = "Dolly";
            this.ComoZoo.FeaturedAnimal.Type = "Dingo";
            this.ComoZoo.FeaturedAnimal.Weight = 35.3;

            // Make animal pregnant.
            this.ComoZoo.FeaturedAnimal.MakePregnant();
            this.ComoZoo.LadiesRoom.Capacity = 4;
            this.ComoZoo.LadiesRoom.Gender = "Female";
            this.ComoZoo.MensRoom.Capacity = 4;
            this.ComoZoo.MensRoom.Gender = "Male";
            this.ComoZoo.TicketBooth.Attendant = new Employee();
            this.ComoZoo.TicketBooth.TicketPrice = 15.00m;
            this.ComoZoo.TicketBooth.Attendant.Name = "Sam";
            this.ComoZoo.TicketBooth.Attendant.Number = 42;

            // Guest class
            this.ComoZoo.Visitor = new Guest();

            // Guest class
            this.ComoZoo.Visitor.Age = 11;
            this.ComoZoo.Visitor.Name = "Darla";
            this.ComoZoo.Visitor.Wallet = new Wallet();
            this.ComoZoo.Visitor.Wallet.MoneyBalance = 5.25m;
        }

        /// <summary>
        /// Creates the San Diego Zoo and related objects.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void newSanDiegoZooButton_Click(object sender, RoutedEventArgs e)
        {
            // Create instance of SanDiegoZoo
            this.SanDiegoZoo = new Zoo();

            // Assign field values of san diego zoo
            this.SanDiegoZoo.BirthArea = new BirthingRoom();
            this.SanDiegoZoo.Capacity = 3000;
            this.SanDiegoZoo.FeaturedAnimal = new Animal();
            this.SanDiegoZoo.LadiesRoom = new Restroom();
            this.SanDiegoZoo.MensRoom = new Restroom();
            this.SanDiegoZoo.Name = "San Diego Zoo";
            this.SanDiegoZoo.TicketBooth = new Booth();
            this.SanDiegoZoo.AnimalSnackMachine = new VendingMachine();

            // Set field values of birth area
            this.SanDiegoZoo.BirthArea.Doctor = new Employee();
            this.SanDiegoZoo.BirthArea.Mother = this.SanDiegoZoo.FeaturedAnimal;
            this.SanDiegoZoo.BirthArea.Temperature = 77;

            // Set field values of doctor
            this.SanDiegoZoo.BirthArea.Doctor.Name = "Steve";
            this.SanDiegoZoo.BirthArea.Doctor.Number = 24;

            // Set field values of featured animal
            this.SanDiegoZoo.FeaturedAnimal.Age = 5;
            this.SanDiegoZoo.FeaturedAnimal.Gender = "Female";
            this.SanDiegoZoo.FeaturedAnimal.Name = "Patti";
            this.SanDiegoZoo.FeaturedAnimal.Type = "Platypus";
            this.SanDiegoZoo.FeaturedAnimal.Weight = 3.27;

            // Set field values of ladiesroom
            this.SanDiegoZoo.LadiesRoom.Capacity = 12;
            this.SanDiegoZoo.LadiesRoom.Gender = "Female";

            // Set field values of mensroom
            this.SanDiegoZoo.MensRoom.Capacity = 12;
            this.SanDiegoZoo.MensRoom.Gender = "Male";

            // Set field values of ticketbooth
            this.SanDiegoZoo.TicketBooth.Attendant = new Employee();
            this.SanDiegoZoo.TicketBooth.TicketPrice = 25.50m;

            // Set field values of ticket booth employee
            this.SanDiegoZoo.TicketBooth.Attendant.Name = "Betty";
            this.SanDiegoZoo.TicketBooth.Attendant.Number = 84;

            // Set field values of vending machine
            this.SanDiegoZoo.AnimalSnackMachine.FoodPricePerPound = 1.20m;
            this.SanDiegoZoo.AnimalSnackMachine.FoodStock = 3.5;
            this.SanDiegoZoo.AnimalSnackMachine.MoneyBalance = 56.25m;

            // Field values of new stuff
            this.SanDiegoZoo.Visitor = new Guest();
            this.SanDiegoZoo.Visitor.Age = 13;
            this.SanDiegoZoo.Visitor.Name = "Dave";
            this.SanDiegoZoo.Visitor.Wallet = new Wallet();
            this.SanDiegoZoo.Visitor.Wallet.MoneyBalance = 3.75m;
        }

        private void darlaFeedDingoButton_Click(object sender, RoutedEventArgs e)
        {
            // Get money from Wallet.
            decimal visitorMoneyBalance = this.ComoZoo.Visitor.GetMoneyBalance();
            double maxFoodWeight = this.ComoZoo.FeaturedAnimal.GetPortionSize();
            decimal foodCost = this.ComoZoo.AnimalSnackMachine.DetermineFoodCost(maxFoodWeight);
            decimal foodPayment = this.ComoZoo.Visitor.RemoveMoney(foodCost);
            double foodWeight = this.ComoZoo.AnimalSnackMachine.SellFood(foodPayment);
            if (visitorMoneyBalance >= foodCost)
            {
                if (visitorMoneyBalance >= 0)
                {
                    this.ComoZoo.Visitor.RemoveMoney(foodCost);
                    this.ComoZoo.AnimalSnackMachine.SellFood(foodPayment);
                    this.ComoZoo.FeaturedAnimal.Eat(foodWeight);
                }
            }
        }

        private void daveFeedPlatypusButton_Click(object sender, RoutedEventArgs e)
        {
            // Get money from Wallet.
            decimal visitorMoneyBalance = this.SanDiegoZoo.Visitor.GetMoneyBalance();
            double maxFoodWeight = this.SanDiegoZoo.FeaturedAnimal.GetPortionSize();
            decimal foodCost = this.SanDiegoZoo.AnimalSnackMachine.DetermineFoodCost(maxFoodWeight);
            decimal foodPayment = this.SanDiegoZoo.Visitor.RemoveMoney(foodCost);
            double foodWeight = this.SanDiegoZoo.AnimalSnackMachine.SellFood(foodPayment);
            if (visitorMoneyBalance >= foodCost)
            {
                this.SanDiegoZoo.Visitor.RemoveMoney(foodCost);
                this.SanDiegoZoo.AnimalSnackMachine.SellFood(foodPayment);
                this.SanDiegoZoo.FeaturedAnimal.Eat(foodWeight);
            }
        }
    }
}